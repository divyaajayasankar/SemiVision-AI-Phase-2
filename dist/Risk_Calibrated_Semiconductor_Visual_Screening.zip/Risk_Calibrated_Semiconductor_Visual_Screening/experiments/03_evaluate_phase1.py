﻿from pathlib import Path
import sys, json
import numpy as np, pandas as pd, torch, matplotlib.pyplot as plt
from sklearn.metrics import RocCurveDisplay, PrecisionRecallDisplay, ConfusionMatrixDisplay
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.config import load_config, ROOT
from src.data import SemDataset
from src.models_convae import ConvAE, count_parameters
from src.scoring import score_dataset
from src.metrics import binary_metrics
from src.localization import fit_localization_threshold, evaluate_localization
from src.utils import write_json, sha256

cfg=load_config(); df=pd.read_csv(ROOT/"results"/"dataset"/"split_manifest.csv"); size=int(cfg["data"]["input_size"])
device=torch.device("cuda" if torch.cuda.is_available() else "cpu"); model=ConvAE(int(cfg["phase1"]["base_channels"])).to(device)
ckpt_path=ROOT/"models"/"convae_best.pt"; ckpt=torch.load(ckpt_path,map_location=device); model.load_state_dict(ckpt.get("model_state",ckpt)); model.eval()
cal=df[(df.split=="calibration")&(df.is_reference==1)]; test=df[df.split=="test"]
cal_sc=score_dataset(model,SemDataset(cal,size),device,batch_size=8); test_sc=score_dataset(model,SemDataset(test,size),device,batch_size=8)
th=float(np.quantile(cal_sc.global_score,float(cfg["phase1"]["threshold_quantile"])))
test_sc["prediction"]=(test_sc.global_score>th).astype(int)
metrics=binary_metrics(test_sc.label,test_sc.global_score,test_sc.prediction,cfg["phase2"]["fn_cost"],cfg["phase2"]["fp_cost"])
metrics.update({"threshold":th,"threshold_quantile":float(cfg["phase1"]["threshold_quantile"]),"calibration_reference_count":len(cal_sc),"test_count":len(test_sc),"model_parameters":count_parameters(model),"checkpoint_sha256":sha256(ckpt_path)})
# Exploratory localization using reference-calibration-derived pixel threshold only.
loc_th=fit_localization_threshold(model,SemDataset(cal,size,include_mask=True),device,float(cfg["phase2"]["localization_reference_quantile"]),batch_size=1)
loc=evaluate_localization(model,SemDataset(test,size,include_mask=True),device,loc_th,int(cfg["phase2"]["pixel_auc_samples_per_image"]),batch_size=1)
metrics["localization_exploratory"]=loc; metrics["localization_threshold"]=loc_th
out=ROOT/"results"/"phase1"; out.mkdir(parents=True,exist_ok=True); test_sc.to_csv(out/"predictions.csv",index=False); write_json(out/"metrics.json",metrics)
policy={"threshold":th,"threshold_quantile":float(cfg["phase1"]["threshold_quantile"]),"calibration_reference_count":len(cal_sc),"checkpoint_sha256":sha256(ckpt_path)}; write_json(ROOT/"models"/"phase1_policy.json",policy)
figdir=ROOT/"results"/"figures"; figdir.mkdir(parents=True,exist_ok=True)
RocCurveDisplay.from_predictions(test_sc.label,test_sc.global_score); plt.tight_layout(); plt.savefig(figdir/"phase1_roc.png",dpi=180); plt.close()
PrecisionRecallDisplay.from_predictions(test_sc.label,test_sc.global_score); plt.tight_layout(); plt.savefig(figdir/"phase1_pr.png",dpi=180); plt.close()
ConfusionMatrixDisplay.from_predictions(test_sc.label,test_sc.prediction); plt.tight_layout(); plt.savefig(figdir/"phase1_confusion.png",dpi=180); plt.close()
plt.hist(cal_sc.global_score,bins=30,alpha=.6,label="Reference calibration"); plt.hist(test_sc[test_sc.label==1].global_score,bins=30,alpha=.6,label="Test anomaly"); plt.legend(); plt.xlabel("Global reconstruction error"); plt.ylabel("Count"); plt.tight_layout(); plt.savefig(figdir/"phase1_score_distribution.png",dpi=180); plt.close()
print(json.dumps(metrics,indent=2))

